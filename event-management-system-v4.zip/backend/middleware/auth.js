const jwt = require('jsonwebtoken');
module.exports = function(requiredRole){
  return function(req,res,next){
    const auth = req.headers.authorization;
    if(!auth) return res.status(401).json({error:'No token'});
    const token = auth.replace('Bearer ','') || auth;
    try {
      const data = jwt.verify(token, process.env.JWT_SECRET || 'change_this_jwt_secret');
      req.user = data;
      if(requiredRole && data.role !== requiredRole && data.role !== 'admin') return res.status(403).json({error:'Forbidden'});
      next();
    } catch(e){ res.status(401).json({error:'Invalid token'}); }
  };
};
