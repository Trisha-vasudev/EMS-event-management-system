require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const xss = require('xss-clean');
const { sequelize, User } = require('./models');
const eventRoutes = require('./routes/events');
const registrationRoutes = require('./routes/registrations');
const authRoutes = require('./routes/auth');
const paymentRoutes = require('./routes/payments');
const notificationRoutes = require('./routes/notifications');
const adminRoutes = require('./routes/admin');

const app = express();

// Security middlewares
app.use(helmet());
app.use(xss());
const limiter = rateLimit({ windowMs: 1*60*1000, max: 100 }); // 100 requests per minute per IP
app.use(limiter);

// CORS - restrict origin in production by setting FRONTEND_URL env var
const allowedOrigin = process.env.FRONTEND_URL || 'http://localhost:5173';
app.use(cors({ origin: allowedOrigin }));

app.use(bodyParser.json());
app.use('/uploads', express.static('uploads'));

// Bull queue setup (Redis)
const Queue = require('bull');
const redisUrl = process.env.REDIS_URL || 'redis://127.0.0.1:6379';
const notificationQueue = new Queue('notifications', redisUrl);
// start worker (worker will process jobs)
require('./worker')(notificationQueue);

app.use('/api/auth', authRoutes);
app.use('/api/events', eventRoutes);
app.use('/api/registrations', registrationRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/admin', adminRoutes);

app.get('/api/health', (req,res)=> res.json({ok:true}));

const PORT = process.env.PORT || 4000;
sequelize.sync({ alter: true }).then(async ()=> {
  // seed admin user if not exists (use env vars)
  try {
    const adminEmail = process.env.ADMIN_SEED_EMAIL;
    const adminPass = process.env.ADMIN_SEED_PASSWORD;
    if(adminEmail && adminPass){
      const existing = await User.findOne({ where:{ email: adminEmail } });
      if(!existing){
        const bcrypt = require('bcryptjs');
        const passwordHash = await bcrypt.hash(adminPass, 10);
        await User.create({ name:'Admin', email: adminEmail, passwordHash, role: 'admin' });
        console.log('Seeded admin user:', adminEmail);
      }
    }
  } catch(e){ console.error('Seeding admin failed', e); }

  app.listen(PORT, () => console.log('Server running on', PORT));
}).catch(err=>{ console.error(err); });
