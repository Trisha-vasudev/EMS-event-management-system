const Queue = require('bull');
const redisUrl = process.env.REDIS_URL || 'redis://127.0.0.1:6379';
let _queue = null;
module.exports.getQueue = function(){
  if(!_queue) _queue = new Queue('notifications', redisUrl);
  return _queue;
};
