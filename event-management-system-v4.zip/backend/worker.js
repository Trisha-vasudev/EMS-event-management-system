module.exports = function(notificationQueue){
  const sgMail = require('@sendgrid/mail');
  const { Notification } = require('./models');
  if(process.env.SENDGRID_API_KEY) sgMail.setApiKey(process.env.SENDGRID_API_KEY);

  // process notification jobs
  notificationQueue.process(async (job) => {
    const { type, to, subject, text, notificationId } = job.data;
    try {
      if(type === 'generate_ticket'){
        const { registrationId, transactionId } = job.data;
        const { Registration, Transaction } = require('./models');
        const reg = await Registration.findByPk(registrationId);
        const tx = transactionId ? await Transaction.findByPk(transactionId) : null;
        if(reg){
          // generate pdf ticket (reuse payments.generateTicket logic simplified here)
          const PDFDocument = require('pdfkit');
          const QRCode = require('qrcode');
          const fs = require('fs');
          const path = require('path');
          const outDir = path.join(__dirname, 'uploads', 'tickets'); if(!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive:true });
          const filePath = path.join(outDir, `ticket_${reg.id}_${Date.now()}.pdf`);
          const doc = new PDFDocument();
          const stream = fs.createWriteStream(filePath);
          doc.pipe(stream);
          doc.fontSize(20).text('E-Ticket', { align:'center' });
          doc.moveDown();
          doc.fontSize(14).text(`Name: ${reg.fullName}`);
          doc.text(`Email: ${reg.email}`);
          doc.text(`Ticket Category: ${reg.ticketCategory}`);
          doc.text(`Transaction: ${tx?tx.id:'n/a'}`);
          doc.moveDown();
          const qrData = JSON.stringify({ regId: reg.id, txId: tx?tx.id:null });
          const qrImageDataUrl = await QRCode.toDataURL(qrData);
          const base64 = qrImageDataUrl.split(',')[1];
          const imgBuffer = Buffer.from(base64, 'base64');
          doc.image(imgBuffer, { fit:[150,150], align:'center' });
          doc.end();
          await new Promise(resolve => stream.on('finish', resolve));
          // send email with attachment if sendgrid configured
          if(process.env.SENDGRID_API_KEY){
            const sgMail = require('@sendgrid/mail'); sgMail.setApiKey(process.env.SENDGRID_API_KEY);
            const attachment = fs.readFileSync(filePath).toString('base64');
            const msg = { to: reg.email, from: process.env.EMAIL_FROM || 'no-reply@example.com', subject: 'Your E-Ticket', text: 'Attached is your e-ticket', attachments:[{ content: attachment, filename: 'ticket.pdf', type: 'application/pdf', disposition: 'attachment' }] };
            await sgMail.send(msg);
            if(job.data.notificationId){ const { Notification } = require('./models'); await Notification.update({ status:'sent' }, { where:{ id: job.data.notificationId } }); }
          }
        }
        return Promise.resolve();
      }
      if(type === 'email' && process.env.SENDGRID_API_KEY){
        await sgMail.send({ to, from: process.env.EMAIL_FROM || 'no-reply@example.com', subject, text });
        if(notificationId) await Notification.update({ status:'sent' }, { where:{ id: notificationId } });
      } else {
        // In dev, just mark as sent
        if(notificationId) await Notification.update({ status:'sent' }, { where:{ id: notificationId } });
      }
      return Promise.resolve();
    } catch(e){
      console.error('Job failed', e);
      if(notificationId) await Notification.update({ status:'failed', metadata: JSON.stringify({ error: e.message }) }, { where:{ id: notificationId } });
      throw e;
    }
  });
};
