const { Sequelize } = require('sequelize');
const sequelize = new Sequelize(process.env.DATABASE_URL || 'sqlite:./database.sqlite', { logging:false });

const User = require('./user')(sequelize);
const Event = require('./event')(sequelize);
const Registration = require('./registration')(sequelize);
const Transaction = require('./transaction')(sequelize);
const Notification = require('./notification')(sequelize);

// associations
Event.hasMany(Registration, { as: 'registrations', foreignKey: 'eventId' });
Registration.belongsTo(Event, { foreignKey: 'eventId' });

Event.hasMany(Transaction, { as: 'transactions', foreignKey: 'eventId' });
Transaction.belongsTo(Event, { foreignKey: 'eventId' });

User.hasMany(Notification, { as: 'notifications', foreignKey: 'userId' });
Notification.belongsTo(User, { foreignKey: 'userId' });

module.exports = { sequelize, User, Event, Registration, Transaction, Notification };
