const { DataTypes } = require('sequelize');
module.exports = (sequelize) => {
  const Transaction = sequelize.define('Transaction', {
    amount: { type: DataTypes.FLOAT, allowNull:false },
    currency: { type: DataTypes.STRING, defaultValue: 'USD' },
    provider: { type: DataTypes.STRING }, // stripe/razorpay/etc
    providerRef: { type: DataTypes.STRING },
    status: { type: DataTypes.STRING, defaultValue: 'pending' } // pending, success, failed
  });
  return Transaction;
};
