const { DataTypes } = require('sequelize');
module.exports = (sequelize) => {
  const Notification = sequelize.define('Notification', {
    type: { type: DataTypes.STRING, allowNull:false }, // email, sms, app
    recipient: { type: DataTypes.STRING },
    message: { type: DataTypes.TEXT },
    status: { type: DataTypes.STRING, defaultValue: 'queued' }, // queued, sent, failed
    metadata: { type: DataTypes.TEXT } // JSON
  });
  return Notification;
};
