const { DataTypes } = require('sequelize');
module.exports = (sequelize) => {
  const Registration = sequelize.define('Registration', {
    fullName: { type: DataTypes.STRING, allowNull:false },
    email: { type: DataTypes.STRING, allowNull:false },
    phone: { type: DataTypes.STRING },
    ticketCategory: { type: DataTypes.STRING, defaultValue: 'General' },
    paid: { type: DataTypes.BOOLEAN, defaultValue:false },
    paymentRef: { type: DataTypes.STRING }
  });
  return Registration;
};
