const { DataTypes } = require('sequelize');
module.exports = (sequelize) => {
  const Event = sequelize.define('Event', {
    title: { type: DataTypes.STRING, allowNull:false },
    description: { type: DataTypes.TEXT },
    location: { type: DataTypes.STRING },
    startDate: { type: DataTypes.DATE, allowNull:false },
    endDate: { type: DataTypes.DATE },
    capacity: { type: DataTypes.INTEGER, defaultValue:100 },
    isPublished: { type: DataTypes.BOOLEAN, defaultValue:false },
    supportFiles: { type: DataTypes.TEXT } // JSON array of filenames
  });
  return Event;
};
