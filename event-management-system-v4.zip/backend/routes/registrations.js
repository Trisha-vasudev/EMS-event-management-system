const express = require('express');
const router = express.Router();
const { Registration, Event } = require('../models');
const auth = require('../middleware/auth');
const validator = require('validator');

// Create registration (validation basic) - attendee
router.post('/', async (req,res)=>{
  try {
    const { eventId, fullName, email, phone, ticketCategory } = req.body;
    if(!eventId || !fullName || !email) return res.status(400).json({error:'Missing required fields'});
    if(!validator.isEmail(email)) return res.status(400).json({ error:'Invalid email' });
    const event = await Event.findByPk(eventId);
    if(!event) return res.status(404).json({error:'Event not found'});
    const reg = await Registration.create({ eventId, fullName: validator.escape(fullName), email, phone: phone?validator.escape(phone):null, ticketCategory });
    res.json(reg);
  } catch (err) { res.status(400).json({error: err.message}); }
});

// other routes remain unchanged...
module.exports = router;
