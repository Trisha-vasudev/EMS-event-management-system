const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const { Registration, Event, Transaction } = require('../models');

// Simple analytics summary for dashboard (organizer/admin)
router.get('/analytics/summary', auth('organizer'), async (req,res)=>{
  const totalRegistrations = await Registration.count();
  const paidCount = await Registration.count({ where:{ paid:true } });
  const totalRevenueRows = await Transaction.findAll({ where:{ status:'success' } });
  const revenue = totalRevenueRows.reduce((s,r)=>s + (r.amount||0), 0);
  res.json({ totalRegistrations, paidCount, revenue });
});

module.exports = router;
