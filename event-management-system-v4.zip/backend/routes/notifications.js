const express = require('express');
const router = express.Router();
const { Notification } = require('../models');
const auth = require('../middleware/auth');
const validator = require('validator');
const sgMail = require('@sendgrid/mail');

if(process.env.SENDGRID_API_KEY){
  sgMail.setApiKey(process.env.SENDGRID_API_KEY);
}

// List notifications (admin/organizer)
router.get('/', auth('organizer'), async (req,res)=>{
  const notes = await Notification.findAll({ order:[['createdAt','DESC']] });
  res.json(notes);
});

// Send announcement to all registrants (organizer)
// Body: { message, eventId }
router.post('/announce', auth('organizer'), async (req,res)=>{
  const { message, eventId } = req.body;
  if(!message || typeof message !== 'string' || validator.isEmpty(message,{ ignore_whitespace:true })) return res.status(400).json({ error:'Message required' });
  // queue notification record
  const note = await Notification.create({ type:'email', recipient:'all_event_registrants', message, status:'queued', userId:null, metadata: JSON.stringify({ eventId }) });
  // enqueue a demo email to admin for now
  const notificationQueue = require('../queue').getQueue();
  await notificationQueue.add({ type:'email', to: process.env.ADMIN_SEED_EMAIL || process.env.EMAIL_FROM, subject: 'Announcement', text: message, notificationId: note.id });
  // If SendGrid configured, optionally send a broadcast email (careful: in prod use batched jobs)
  /* enqueued above for background processing */
  res.json({ ok:true });
});

// Simple send email endpoint (demo). Uses SendGrid if configured.
router.post('/send-email', auth('organizer'), async (req,res)=>{
  const { to, subject, text } = req.body;
  if(!to || !validator.isEmail(to)) return res.status(400).json({ error: 'Valid "to" email required' });
  if(!subject || !text) return res.status(400).json({ error: 'subject and text required' });
  const note = await Notification.create({ type:'email', recipient:to, message:text, status:'queued', userId:null });
  const notificationQueue = require('../queue').getQueue();
  await notificationQueue.add({ type:'email', to, subject, text, notificationId: note.id });
  res.json({ ok:true, queued:true });
});

module.exports = router;
