const express = require('express');
const router = express.Router();
const multer = require('multer');
const upload = multer({ dest: 'uploads/' });
const { Event, Notification, Registration } = require('../models');
const auth = require('../middleware/auth');

// Create event (organizer/admin)
router.post('/', auth('organizer'), upload.array('files'), async (req,res) => {
  try {
    const data = req.body;
    const files = (req.files || []).map(f=>f.filename);
    const event = await Event.create({ ...data, supportFiles: JSON.stringify(files) });
    res.json(event);
  } catch (err) { res.status(400).json({error: err.message}); }
});

// Edit event
router.put('/:id', auth('organizer'), upload.array('files'), async (req,res)=>{
  try {
    const event = await Event.findByPk(req.params.id);
    if(!event) return res.status(404).json({error:'Not found'});
    const files = (req.files || []).map(f=>f.filename);
    await event.update({ ...req.body, supportFiles: JSON.stringify(files.length?files:JSON.parse(event.supportFiles || '[]')) });
    res.json(event);
  } catch(e){ res.status(400).json({error: e.message}); }
});

// Publish event - enqueue notifications to registered attendees
router.post('/:id/publish', auth('organizer'), async (req,res)=>{
  const ev = await Event.findByPk(req.params.id);
  if(!ev) return res.status(404).json({error:'Not found'});
  await ev.update({ isPublished:true });
  // find registrations and create notifications (queued)
  const regs = await Registration.findAll({ where:{ eventId: ev.id } });
  for(const r of regs){
    await Notification.create({ type:'email', recipient:r.email, message:`Event ${ev.title} is now published`, status:'queued', userId:null });
  }
  res.json({ok:true, published:true});
});

// Delete
router.delete('/:id', auth('organizer'), async (req,res)=>{
  const ev = await Event.findByPk(req.params.id);
  if(!ev) return res.status(404).json({error:'Not found'});
  await ev.destroy();
  res.json({ok:true});
});

// List (only published by default)
router.get('/', async (req,res)=>{
  const { all } = req.query;
  const where = all==='true' ? {} : { isPublished:true };
  const events = await Event.findAll({ where, order:[['startDate','ASC']] });
  res.json(events);
});

// Detail
router.get('/:id', async (req,res)=>{
  const ev = await Event.findByPk(req.params.id);
  if(!ev) return res.status(404).json({error:'Not found'});
  res.json(ev);
});

module.exports = router;
