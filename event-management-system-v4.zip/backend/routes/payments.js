const express = require('express');
const router = express.Router();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY || '');
const { Registration, Transaction, Event } = require('../models');
const PDFDocument = require('pdfkit');
const QRCode = require('qrcode');
const fs = require('fs');
const path = require('path');

// Create a payment intent (Stripe) - demo mode (STRIPE_SECRET_KEY required)
router.post('/create-intent', async (req,res)=>{
  try {
    const { registrationId, amount, currency } = req.body;
    const reg = await Registration.findByPk(registrationId);
    if(!reg) return res.status(404).json({error:'Registration not found'});
    // create a transaction record
    const tx = await Transaction.create({ amount, currency: currency||'USD', provider:'stripe', status:'pending', eventId: reg.eventId });
    if(!process.env.STRIPE_SECRET_KEY){
      // no stripe key - simulate success for local dev
      await reg.update({ paid:true, paymentRef: 'SIMULATED-'+tx.id });
      await tx.update({ status:'success', providerRef: 'SIMULATED-'+tx.id });
      // generate e-ticket
      const ticketPath = await generateTicket(reg, tx);
      return res.json({ simulated:true, ticketPath, registration: reg, transaction: tx });
    }
    const intent = await stripe.paymentIntents.create({ amount: Math.round(amount*100), currency: currency||'usd', metadata:{ registrationId: reg.id, transactionId: tx.id } });
    res.json({ clientSecret: intent.client_secret, intentId: intent.id, transactionId: tx.id });
  } catch(err){ res.status(500).json({error:err.message}); }
});

// webhook stub (to be configured in Stripe dashboard)
router.post('/webhook', express.raw({type:'application/json'}), async (req,res)=>{
  // Stripe webhook handler: verify signature in production
  try {
    const payload = req.body;
    const sig = req.headers['stripe-signature'];
    let eventObj = payload;
    if(process.env.STRIPE_SECRET_KEY && sig){
      const stripeLib = require('stripe')(process.env.STRIPE_SECRET_KEY);
      try {
        eventObj = stripeLib.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET || '');
      } catch(e){
        console.error('Stripe signature verification failed', e.message);
        return res.status(400).end();
      }
    }
    // handle payment_intent.succeeded
    if(eventObj.type === 'payment_intent.succeeded' || (eventObj.data && eventObj.data.object && eventObj.data.object.status === 'succeeded')){
      const pi = eventObj.data.object;
      const txId = pi.metadata && pi.metadata.transactionId;
      const registrationId = pi.metadata && pi.metadata.registrationId;
      const { Transaction, Registration } = require('../models');
      // update transaction & registration
      if(txId){ await Transaction.update({ status:'success', providerRef: pi.id }, { where:{ id: txId } }); }
      if(registrationId){ const reg = await Registration.findByPk(registrationId); if(reg){ await reg.update({ paid:true, paymentRef: pi.id }); }
      }
      // enqueue ticket generation job (simple implementation)
      const notificationQueue = require('../queue').getQueue();
      await notificationQueue.add({ type:'generate_ticket', registrationId, transactionId: txId });
    }
    res.json({received:true});
  } catch(e){ console.error(e); res.status(400).json({error:e.message}); }
});

async function generateTicket(reg, tx){
  // create a PDF ticket with QR code (saved to /uploads/tickets)
  const outDir = path.join(__dirname, '..', 'uploads', 'tickets');
  if(!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive:true });
  const filePath = path.join(outDir, `ticket_${reg.id}_${Date.now()}.pdf`);
  const doc = new PDFDocument();
  const stream = fs.createWriteStream(filePath);
  doc.pipe(stream);
  doc.fontSize(20).text('E-Ticket', { align:'center' });
  doc.moveDown();
  doc.fontSize(14).text(`Name: ${reg.fullName}`);
  doc.text(`Email: ${reg.email}`);
  doc.text(`Ticket Category: ${reg.ticketCategory}`);
  doc.text(`Transaction: ${tx.id}`);
  doc.moveDown();
  const qrData = JSON.stringify({ regId: reg.id, txId: tx.id });
  const qrImageDataUrl = await QRCode.toDataURL(qrData);
  // embed QR image
  const base64 = qrImageDataUrl.split(',')[1];
  const imgBuffer = Buffer.from(base64, 'base64');
  doc.image(imgBuffer, { fit:[150,150], align:'center' });
  doc.end();
  await new Promise(resolve => stream.on('finish', resolve));
  return filePath;
}

module.exports = router;
