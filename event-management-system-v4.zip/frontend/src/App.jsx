import React from 'react';
import { Outlet, Link } from 'react-router-dom';

export default function App(){
  return (
    <div style={{fontFamily:'Arial, sans-serif', padding:20}}>
      <header>
        <h1><Link to='/'>Event Management System</Link></h1>
        <nav><Link to='/'>Events</Link> | <Link to='/admin'>Admin</Link> | <Link to='/login'>Login</Link> | <Link to='/admin/events'>Manage Events</Link> | <Link to='/admin/notifications'>Notifications</Link></nav>
      </header>
      <main style={{marginTop:20}}>
        <Outlet />
      </main>
    </div>
  );
}
