import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

export default function EventDetail(){
  const { id } = useParams();
  const [event,setEvent] = useState(null);
  const [form, setForm] = useState({ fullName:'', email:'', phone:'', ticketCategory:'General' });
  useEffect(()=>{ axios.get('http://localhost:4000/api/events/'+id).then(r=>setEvent(r.data)).catch(()=>{}); },[id]);

  async function submit(e){
    e.preventDefault();
    const payload = { eventId: id, ...form };
    const reg = await axios.post('http://localhost:4000/api/registrations', payload);
    // If you have Stripe test key, call payments/create-intent to initiate payment
    alert('Registered (demo). For paid tickets, follow payment flow in the UI (if configured).');
  }

  if(!event) return <div>Loading...</div>;
  return (
    <div>
      <h2>{event.title}</h2>
      <p>{event.description}</p>
      <p><strong>When:</strong> {new Date(event.startDate).toLocaleString()}</p>

      <h3>Register</h3>
      <form onSubmit={submit}>
        <div><input placeholder="Full name" value={form.fullName} onChange={e=>setForm({...form, fullName:e.target.value})} required /></div>
        <div><input placeholder="Email" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} required /></div>
        <div><input placeholder="Phone" value={form.phone} onChange={e=>setForm({...form, phone:e.target.value})} /></div>
        <div><select value={form.ticketCategory} onChange={e=>setForm({...form, ticketCategory:e.target.value})}><option>General</option><option>VIP</option></select></div>
        <button type="submit">Register</button>
      </form>
    </div>
  );
}
