import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Login(){
  const [form, setForm] = useState({ email:'', password:'' });
  const nav = useNavigate();

  async function submit(e){
    e.preventDefault();
    try{
      const res = await axios.post('http://localhost:4000/api/auth/login', form);
      localStorage.setItem('token', res.data.token);
      alert('Logged in');
      nav('/admin');
    }catch(e){ alert('Login failed'); }
  }

  return (
    <div style={{maxWidth:400}}>
      <h2>Login</h2>
      <form onSubmit={submit}>
        <div><input placeholder="Email" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} required /></div>
        <div><input type="password" placeholder="Password" value={form.password} onChange={e=>setForm({...form, password:e.target.value})} required /></div>
        <button>Login</button>
      </form>
    </div>
  );
}
