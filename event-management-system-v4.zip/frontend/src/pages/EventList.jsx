import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

export default function EventList(){
  const [events,setEvents] = useState([]);
  useEffect(()=>{ axios.get('http://localhost:4000/api/events').then(r=>setEvents(r.data)).catch(()=>{}); },[]);
  return (
    <div>
      <h2>Upcoming Events</h2>
      {events.length===0 ? <p>No events yet.</p> : (
        <ul>
          {events.map(ev=>(
            <li key={ev.id}>
              <Link to={'/events/'+ev.id}>{ev.title}</Link> — {new Date(ev.startDate).toLocaleString()}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
