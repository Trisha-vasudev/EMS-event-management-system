import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

function authHeader(){ const t = localStorage.getItem('token'); return t? { Authorization: 'Bearer '+t } : {}; }

export default function AdminDashboard(){
  const [summary, setSummary] = useState({ totalRegistrations:0, paidCount:0, revenue:0 });
  useEffect(()=>{
    axios.get('http://localhost:4000/api/admin/analytics/summary', { headers: authHeader() })
      .then(r=>setSummary(r.data))
      .catch(()=>{});
  },[]);

  const data = [{ name:'Registrations', value: summary.totalRegistrations }, { name:'Paid', value: summary.paidCount }, { name:'Revenue', value: summary.revenue }];

  return (
    <div>
      <h2>Admin Dashboard</h2>
      <p>Total registrations: {summary.totalRegistrations}</p>
      <p>Paid: {summary.paidCount}</p>
      <p>Revenue: {summary.revenue}</p>

      <div style={{width:'100%', height:300}}>
        <ResponsiveContainer>
          <BarChart data={data}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="value" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
