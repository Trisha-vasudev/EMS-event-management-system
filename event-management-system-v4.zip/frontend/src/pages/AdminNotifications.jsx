import React, { useState } from 'react';
import api from '../api';

function authHeader(){ const t = localStorage.getItem('token'); return t? { Authorization: 'Bearer '+t } : {}; }

export default function AdminNotifications(){
  const [msg, setMsg] = useState('');
  const [eventId, setEventId] = useState('');
  const [to, setTo] = useState('');
  const [subject, setSubject] = useState('');

  async function announce(e){
    e.preventDefault();
    await api.post('/notifications/announce', { message: msg, eventId }, { headers: authHeader() });
    alert('Announcement queued');
  }

  async function sendEmail(e){
    e.preventDefault();
    await api.post('/notifications/send-email', { to, subject, text: msg }, { headers: authHeader() });
    alert('Email send requested');
  }

  return (
    <div>
      <h2>Admin - Notifications</h2>
      <form onSubmit={announce}>
        <textarea placeholder="Announcement message" value={msg} onChange={e=>setMsg(e.target.value)} required />
        <input placeholder="Event ID (optional)" value={eventId} onChange={e=>setEventId(e.target.value)} />
        <button>Announce to event registrants</button>
      </form>

      <hr />
      <h3>Send Direct Email</h3>
      <form onSubmit={sendEmail}>
        <input placeholder="To" value={to} onChange={e=>setTo(e.target.value)} required />
        <input placeholder="Subject" value={subject} onChange={e=>setSubject(e.target.value)} required />
        <textarea placeholder="Body" value={msg} onChange={e=>setMsg(e.target.value)} required />
        <button>Send Email</button>
      </form>
    </div>
  );
}
