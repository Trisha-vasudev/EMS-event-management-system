import React, { useEffect, useState } from 'react';
import api from '../api';

function authHeader(){ const t = localStorage.getItem('token'); return t? { Authorization: 'Bearer '+t } : {}; }

export default function AdminEvents(){
  const [events, setEvents] = useState([]);
  const [form, setForm] = useState({ title:'', description:'', location:'', startDate:'', endDate:'', capacity:100 });
  useEffect(()=>{ fetchEvents(); },[]);

  function fetchEvents(){ api.get('/events?all=true', { headers: authHeader() }).then(r=>setEvents(r.data)).catch(()=>{}); }

  async function create(e){
    e.preventDefault();
    try{
      await api.post('/events', form, { headers: authHeader() });
      alert('Created');
      setForm({ title:'', description:'', location:'', startDate:'', endDate:'', capacity:100 });
      fetchEvents();
    }catch(e){ alert('Failed to create'); }
  }

  async function publish(id){
    await api.post('/events/'+id+'/publish', {}, { headers: authHeader() });
    alert('Published');
    fetchEvents();
  }

  return (
    <div>
      <h2>Admin - Events</h2>
      <form onSubmit={create} style={{maxWidth:600}}>
        <input placeholder="Title" value={form.title} onChange={e=>setForm({...form, title:e.target.value})} required />
        <textarea placeholder="Description" value={form.description} onChange={e=>setForm({...form, description:e.target.value})} />
        <input placeholder="Location" value={form.location} onChange={e=>setForm({...form, location:e.target.value})} />
        <input type="datetime-local" value={form.startDate} onChange={e=>setForm({...form, startDate:e.target.value})} required />
        <input type="datetime-local" value={form.endDate} onChange={e=>setForm({...form, endDate:e.target.value})} />
        <input type="number" value={form.capacity} onChange={e=>setForm({...form, capacity:parseInt(e.target.value||0)})} />
        <button>Create Event</button>
      </form>

      <h3>Existing Events</h3>
      <ul>
        {events.map(ev=> <li key={ev.id}>{ev.title} — {ev.isPublished ? 'Published' : 'Draft'} <button onClick={()=>publish(ev.id)}>Publish</button></li>)}
      </ul>
    </div>
  );
}
