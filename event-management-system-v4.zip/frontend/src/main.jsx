import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import App from './App';
import EventList from './pages/EventList';
import EventDetail from './pages/EventDetail';
import Login from './pages/Login';
import AdminDashboard from './pages/AdminDashboard';
import AdminEvents from './pages/AdminEvents';
import AdminNotifications from './pages/AdminNotifications';

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<App />}>
          <Route index element={<EventList />} />
          <Route path='login' element={<Login />} />
          <Route path='events/:id' element={<EventDetail />} />
          <Route path='admin' element={<AdminDashboard />} />
          <Route path='admin/events' element={<AdminEvents />} />
          <Route path='admin/notifications' element={<AdminNotifications />} />
        </Route>
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);
